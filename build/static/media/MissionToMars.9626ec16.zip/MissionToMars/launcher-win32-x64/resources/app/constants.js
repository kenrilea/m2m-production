const launcherRoot = __dirname
const gameRoot = __dirname + '/game'
const updateServiceUri = 'http://missiontomars.ca:3389'

module.exports = {
  launcherRoot,
  gameRoot,
  updateServiceUri,
}
