import React from 'react'
import styled from 'styled-components'

const LogContainer = styled.div`
  height: 100px;
  padding: 1rem;
  width: 80%;
  border: 1px solid #993300;
  color: whitesmoke;
  .message {
    color: #548204;
    list-style-type: none;
  }
`

const Console = ({ logs }) => {
  console.log(logs, 'console')
  return (
    <LogContainer>
      {logs.map((text, i) => {
        return (
          <li className='message' key={i}>
            {'>' + text}
          </li>
        )
      })}
    </LogContainer>
  )
}
export default Console
