const { ipcMain } = require('electron')
let win = null

const log = (message) => {
  if (!win) {
    console.log('window ref invalid:', win)
    return
  }
  console.log(message)
  win.webContents.send('syncMessage', message)
}

const utilModule = (winRef) => {
  console.log(winRef)
  win = winRef
  return {
    log,
  }
}

module.exports = utilModule
