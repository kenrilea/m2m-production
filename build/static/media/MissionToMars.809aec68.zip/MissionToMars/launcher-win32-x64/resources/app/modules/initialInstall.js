const getManifest = require('./getManifest')
const axios = require('axios')
const { updateServiceUri, launcherRoot } = require('../constants')
const fs = require('fs')

const initialInstall = async (targetRoot, log) => {
  log('installing mission to mars')
  // first we need the file manifest
  log('fetching file manifest')
  let manifest = await getManifest()
  log('building directory structure')
  // we then prepare the directory structure for the files
  if (!fs.existsSync(targetRoot)) {
    fs.mkdirSync(targetRoot)
  }
  // we get all of the game files
  log('fetching game files...')
  let drained = false
  const files = await Promise.all(
    manifest.map(async (fileData) => {
      return new Promise(async (resolve, reject) => {
        let wrapup = () => {
          resolve({ success: true })
        }
        let finalPath = fileData.path.replace(':root', targetRoot)
        let targetDir = finalPath.split('/')
        targetDir.pop()
        targetDir = targetDir.join('/')
        const exists = fs.existsSync(targetDir)
        if (!exists) {
          fs.mkdirSync(targetDir, { recursive: true })
        }
        console.log(`downloading ${targetDir}`)
        const download = async (url, dest, cb) => {
          try {
            const writeStream = fs.createWriteStream(dest, {
              autoClose: true,
              emitClose: true,
            })
            const res = await axios.request({
              method: 'post',
              headers: { 'Content-Type': 'application/json' },
              url,
              data: JSON.stringify({ file: fileData.path }),
              responseType: 'stream',
            })
            res.data.pipe(writeStream)
            let fileName = fileData.path.split('/').pop()
            log(`writing file ${fileName}`)
            writeStream.on('error', (e) => {
              log('file write error', e)
            })
            writeStream.on('finish', () => {
              log('file written', dest)
              writeStream.close(cb)
            })
          } catch (e) {
            console.log('file DL error', e)
            return e
          }
        }
        const status = await download(
          updateServiceUri + '/fetch-file',
          fileData.path.replace(':root', targetRoot),
          wrapup
        )
        if (status.success) {
          resolve(true)
        } else {
          console.log(status)
          resolve(false)
        }
      })
    })
  )
  log('files fetched')
  if (files.every((success) => success)) {
    fs.writeFile(
      launcherRoot + '/manifest.json',
      JSON.stringify(manifest),
      (e) => {
        if (e) console.log('manifest write error', e)
      }
    )
    return { success: true }
  }
  return { success: false }
  //then we verify their contents
}

module.exports = initialInstall
