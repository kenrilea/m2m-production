import React, { useEffect, useMemo, useReducer, useRef } from 'react'
import { Row } from '../StyledComponents/Row'
import { Button } from '../StyledComponents/Button'
import Console from './Console.jsx'
import styled from 'styled-components'

const { ipcRenderer } = require('electron')

const Layout = styled.div`
  height: 100%;
  .header {
    width: 100%;
  }
`

const Banner = styled.div`
  font-size: 72px;
  margin: 1rem;
  color: whitesmoke;
  color: #993300;
  text-align: center;
`

let logs = []

const testClick = () => {
  ipcRenderer.send('launchGame', 'LAUNCH')
}

ipcRenderer.on('dataFlow', (event, message) => {
  // reducer-like functions to manipulate data from main thread go here
})

const initialState = {
  logs: [],
}

const reducer = (state, action) => {
  switch (action.type) {
    case 'USER_LOG':
      return { ...state, logs: action.logs }
    default:
      return { ...state }
  }
}

const Main = () => {
  const [state, dispatch] = useReducer(reducer, initialState)

  useEffect(() => {
    ipcRenderer.on('syncMessage', (event, message) => {
      let newLogs = state.logs.slice()
      if (newLogs.length > 4) {
        newLogs.shift()
      }
      console.log(newLogs, message)
      newLogs.push(message)
      dispatch({ type: 'USER_LOG', logs: newLogs })
    })
  }, [])

  return (
    <Layout>
      <div>
        <Banner>MISSION TO MARS</Banner>
      </div>
      <div>
        <img src='../assets/m2mheader.png' className='header' />
      </div>
      <Row style={{ justifyContent: 'center' }}>
        <Button onClick={testClick}>Launch</Button>
        <Button disabled={true}>Repair</Button>
      </Row>
      <Row style={{ justifyContent: 'center' }}>
        <Console logs={state.logs} />
      </Row>
    </Layout>
  )
}

export default Main
