const axios = require("axios");
const fs = require("fs");
const { launcherRoot, updateServiceUri } = require("../constants.js");

const getManifest = () => {
  const manifest = new Promise(async (rslv, rjct) => {
    try {
      let res = await axios.get(updateServiceUri + "/manifest");
      //console.log(res.data);
      JSON.parse(res.data);
      rslv(JSON.parse(res.data));
    } catch (e) {
      console.log(e);
      rjct(res);
    }
  });
  return manifest;
};

module.exports = getManifest;
