import React from "react";
import { Row } from "../StyledComponents/Row";
import { Button } from "../StyledComponents/Button";
import styled from "styled-components";

const { ipcRenderer } = require("electron");

const Layout = styled.div`
  .header {
    width: 100%;
  }
`;

const Banner = styled.div`
  font-size: 72px;
  margin: 1rem;
  color: whitesmoke;
  text-align: center;
`;

const testClick = () => {
  ipcRenderer.send("sync-message", "LAUNCH");
};

const Main = () => {
  return (
    <Layout>
      <div>
        <Banner>MISSION TO MARS</Banner>
      </div>
      <div>
        <img src="../assets/m2mheader.png" className="header" />
      </div>
      <Row style={{ justifyContent: "center" }}>
        <Button onClick={testClick}>Launch</Button>
        <Button>Repair</Button>
      </Row>
    </Layout>
  );
};

export default Main;
